
function validation() {
    let email = document.getElementById("exampleInputEmail1").value;
    let pass = document.getElementById("exampleInputPassword1").value;
    
    
    const xhr = new XMLHttpRequest();
    xhr.open("GET","users.json",true);
     xhr.onload = function (){
        if(xhr.status === 200){
            let data = JSON.parse(xhr.responseText);
    
    for (let i = 0; i < data.users.length; i++) {
        if (data.users[i].emailAddress === email && data.users[i].password === pass) {
            alert("You have successfully logged in.");
            window.location.href = "index.html";
            return;
           

        }
    }
    alert("Enter Correct Username && Password!");

     }  
};

xhr.send();

}


